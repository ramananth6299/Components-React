import React, { Component } from "react";

class Home extends Component {
  render() {
    return (
      <div>
        <h3> Welcome to the Home Page of Student Management Portal </h3>
      </div>
    );
  }
}

export { Home };

// export class Home{};